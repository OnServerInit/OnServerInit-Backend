function changeSort() {
    const e = document.getElementById("sortby");
    const sortby = e.value;

    let key = encodeURIComponent("sort");
    let value = encodeURIComponent(sortby);

    const kvp = document.location.search.substr(1).split('&');
    let i = 0;

    for (; i < kvp.length; i++) {
        if (kvp[i].startsWith(key + '=')) {
            let pair = kvp[i].split('=');
            pair[1] = value;
            kvp[i] = pair.join('=');
            break;
        }
    }

    if (i >= kvp.length) {
        kvp[kvp.length] = [key, value].join('=');
    }
    document.location.search = kvp.join('&');
}

function getQueryVariable(variable) {
    const query = window.location.search.substring(1);
    const vars = query.split("&");
    for (let i = 0; i < vars.length; i++) {
        const pair = vars[i].split("=");
        if (pair[0] === variable) {
            return pair[1];
        }
    }
}

window.addEventListener('load', function () {
    console.log(getQueryVariable("sort"));
    document.getElementById("sortby").value = getQueryVariable("sort").toLowerCase();
});